package io.github.krmdemo.kafkainspect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaInspectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaInspectApplication.class, args);
	}

}
