package io.github.krm_demo.kafka_inspect_21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaInspect21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
