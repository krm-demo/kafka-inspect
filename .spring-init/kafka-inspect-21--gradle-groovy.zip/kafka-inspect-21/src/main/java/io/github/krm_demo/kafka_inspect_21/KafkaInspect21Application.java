package io.github.krm_demo.kafka_inspect_21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaInspect21Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaInspect21Application.class, args);
	}

}
