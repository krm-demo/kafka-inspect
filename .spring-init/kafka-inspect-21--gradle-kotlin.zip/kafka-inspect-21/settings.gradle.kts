rootProject.name = "kafka-inspect-21"
