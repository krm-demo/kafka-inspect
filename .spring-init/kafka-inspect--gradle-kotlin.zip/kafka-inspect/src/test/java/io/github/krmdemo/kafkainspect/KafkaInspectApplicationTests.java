package io.github.krmdemo.kafkainspect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaInspectApplicationTests {

	@Test
	void contextLoads() {
	}

}
