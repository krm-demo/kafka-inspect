rootProject.name = "kafka-inspect"
